Api_peer = "163.239.200.182"
Peer1 = "163.239.200.163"
Peer2 = "163.239.200.162"
Peer3 = "163.239.200.165"
Peer4 = "163.239.200.161"

my_ip_address = None
my_peer_num = None
port = 10654
REST_node_port = 10101
peer_num = 4


my_node = None

trust_ip = ''

my_node_jstr = None
my_node_jobj = None

pub_key = None
pri_key = None

sync_flag = False

tx_count = 0
