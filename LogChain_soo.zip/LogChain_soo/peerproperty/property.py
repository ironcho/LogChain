Api_peer="163.239.200.182"
Peer1="163.239.200.163"
Peer2="163.239.200.162"
Peer3="163.239.200.165"
Peer4="163.239.200.161"

my_ip_address = None
my_peer_num = None
port = 10654
peer_num = 4

