import threading
from peerproperty import property
from peerproperty import set_peer
from storage import file_controller
from communication import receiver
from service.blockmanager import genesisblock
from storage import file_controller

def main():

    'Remove all transaction in mempool'
    #file_controller.remove_all_transactions()
    print ("Logchain Start")


    'Peer setting'
    my_ip_address = file_controller.get_my_ip()
    property.my_ip_address = my_ip_address
    set_peer.set_peer()
    print ("my peer : " + str(property.my_peer_num))

    'Genesis Block Create'
    genesisblock.genesisblock_generate()

    'receiver thread start'
    print("Peer Start. Peer num : " + str(property.my_peer_num))
    threading._start_new_thread(receiver.start("Receiver", my_ip_address, property.port))



if __name__ == '__main__':
    main()

